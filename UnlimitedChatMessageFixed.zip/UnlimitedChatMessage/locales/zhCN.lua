local L = LibStub("AceLocale-3.0"):NewLocale("UnlimitedChatMessage", "zhCN")
if not L then return end
